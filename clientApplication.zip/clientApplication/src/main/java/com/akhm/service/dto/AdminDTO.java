package com.akhm.service.dto;


import lombok.Data;
@Data
public class AdminDTO {
	private Integer adminId;
	private String firstName;
	private String lastName;
	private String emailId;
	private String password;
	
}
