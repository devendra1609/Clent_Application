package com.akhm.exception;

public class MyCustomCustomerException extends RuntimeException{
	public MyCustomCustomerException(String message) {
		super(message);
	}
}
