package com.akhm.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akhm.exception.MyCustomException;
import com.akhm.repository.ProductPriceRepository;
import com.akhm.repository.enity.ProductPriceEntity;
import com.akhm.service.ProductPriceService;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class ProductPriceServiceImpl implements ProductPriceService{
	@Autowired
	private ProductPriceRepository productPriceRepository;
	@Override
	public Integer insertProductPrice(ProductPriceEntity productPriceEntity) {
		log.info("{}-ServiceImpl insertProductPrice() Started");
		try {
			ProductPriceEntity productPrice=productPriceRepository.save(productPriceEntity);
			if(productPrice!=null) {
				return productPrice.getProductPriceId();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("{}-ServiceImpl-insertProductPrice()-exception occured-{}");
			throw new MyCustomException(e.getMessage());
			
		}

	}

	@Override
	public List<ProductPriceEntity> getProductPrices(Integer productId, String status) {
		log.info("{}-ServiceImpl getProductPrices Started");
		try {
			log.info("{}-ServiceImpl getProductPrices() getting ProductPrices");
			return productPriceRepository.findAllByProductIdAndStatus(productId, status);
		} catch (Exception e) {
			log.error("{}-ServiceImpl-getProductPrices()-exception occured-{}");
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public ProductPriceEntity getProductPrice(Integer productId, String status) {
		log.info("{}-ServiceImpl getProductPrice() Started");
		try {
			Optional<ProductPriceEntity> optional=productPriceRepository.findByProductIdAndStatus(productId, status);
			if(optional!=null) {
				return optional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("{}-ServiceImpl-getProductPrice()-exception occured-{}");
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public void updateProductPrice(ProductPriceEntity productPriceEntity) {
		log.info("{}-ServiceImpl updateProductPrice() Started");
		try {
			log.info("{}-ServiceImpl updateProductPrice() Updated ProductPrices");
			productPriceRepository.save(productPriceEntity);
		} catch (Exception e) {
			log.error("{}-ServiceImpl-updateProductPrice()-exception occured-{}");
			throw new MyCustomException(e.getMessage());
		}
		
	}

}
