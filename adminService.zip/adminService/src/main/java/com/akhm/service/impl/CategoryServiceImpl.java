package com.akhm.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akhm.exception.MyCustomException;
import com.akhm.repository.CategoryRepository;
import com.akhm.repository.enity.CategoryEntity;
import com.akhm.service.CategoryService;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class CategoryServiceImpl implements CategoryService{
	@Autowired
	private CategoryRepository categoryRepository;
	@Override
	public Integer insertCategory(CategoryEntity categoryEntity) {
		log.info("{} ServiceImpl insertCategory() Started");
		try {
			log.info("{} ServiceImpl insertCategory() save Category");
			CategoryEntity category=categoryRepository.save(categoryEntity);
			if(category!=null) {
				return category.getCategoryId();
			} else {
				return null;
			}
			
		} catch (Exception e) {
			log.error("{} ServiceImpl-insertCategory()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public List<CategoryEntity> getCategories() {
		log.info("{} ServiceImpl getCategories Started");
		try {
			log.info("{} ServiceImpl getCategories() saving Category");
			return categoryRepository.findAll();
			
		} catch (Exception e) {
			log.error("{} ServiceImpl-getCategories()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}

	}

	@Override
	public CategoryEntity getCategory(Integer categoryId) {
		log.info("{} ServiceImpl getCategory() Started");
		try {
			log.info("{}-ServiceImpl getCategory()getting Categories in repository");
			Optional<CategoryEntity> optional=categoryRepository.findById(categoryId);
			if(optional.isPresent()) {
				return optional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("{} ServiceImpl-getCategory()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public void updateCategory(CategoryEntity categoryEntity) {
		log.info("ServiceImpl updateCategory() Started");
		try {
			log.info("{} ServiceImpl updateCategory()");
			categoryRepository.save(categoryEntity);
		} catch (Exception e) {
			log.error("{} ServiceImpl-updateCategory()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public void deleteCategory(Integer categoryId) {
		try {
			log.info("{} ServiceImpl deleteCategory()");
			categoryRepository.deleteById(categoryId);
		} catch (Exception e) {
			log.error("{} ServiceImpl-deleteCategory()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

}
