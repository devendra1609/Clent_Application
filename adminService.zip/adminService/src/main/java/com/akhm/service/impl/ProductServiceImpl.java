package com.akhm.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akhm.exception.MyCustomException;
import com.akhm.repository.ProductRepository;
import com.akhm.repository.enity.ProductEntity;
import com.akhm.service.ProductService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepository productRepository;
	@Override
	public Integer insertProduct(ProductEntity productEntity) {
		log.info("{}-ServiceImpl insertProduct() Started");
		try {
			log.info("{}-ServiceImpl insertVehicle() saving Product");
			ProductEntity product=productRepository.save(productEntity);
			if(product!=null) {
				return product.getProductId();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("{}-ServiceImpl-insertProduct()-exception occured-{}");
			throw new MyCustomException(e.getMessage());
		}

	}

	@Override
	public List<ProductEntity> getProducts() {
		log.info("{}-ServiceImpl getProducts() Started");
		try {
			log.info("{}-ServiceImpl getProducts() getting Product");
			return productRepository.findAll();
		} catch (Exception e) {
			log.error("{}-ServiceImpl-getProducts()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public ProductEntity getProduct(Integer productId) {
		log.info("{}-ServiceImpl getProduct() Started");
		try {
			log.info("{}-ServiceImpl getProduct() saving Product");
			Optional<ProductEntity> optional=productRepository.findById(productId);
			if(optional!=null) {
				return optional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("{}-ServiceImpl-getProduct()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
	}

	@Override
	public void updateProduct(ProductEntity productEntity) {
		log.info("{}-ServiceImpl updateProduct() Started");
		try {
			log.info("{}-ServiceImpl updateProduct()");
			productRepository.save(productEntity);
		} catch (Exception e) {
			log.error("{}-ServiceImpl-updateProduct()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public void deleteProduct(Integer productId) {
		log.info("{}-ServiceImpl deleteProduct() Started");
		try {
			log.info("{}-ServiceImpl deleteProduct() ");
			productRepository.deleteById(productId);
		} catch (Exception e) {
			log.error("{}-ServiceImpl-deleteProduct()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

}
