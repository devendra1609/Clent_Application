package com.akhm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akhm.exception.MyCustomException;
import com.akhm.repository.AdminRepository;
import com.akhm.repository.enity.AdminEntity;
import com.akhm.service.AdminService;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class AdminServiceImpl implements AdminService{
	@Autowired(required = false)
	private AdminRepository adminRepository;
	public AdminEntity getAdmin(String emailId, String password) {
		log.info("{} ServiceImpl getAdmin() Started");
		try {
			log.info("{} ServiceImpl getAdmin() load Admin");
			return adminRepository.findByEmailIdAndPassword(emailId, password);
		} catch (Exception e) {
			log.error("{}ServiceImpl-getAdmin()-exception occured-{}");
			throw new MyCustomException(e.getMessage());
		}

	}
	

}
