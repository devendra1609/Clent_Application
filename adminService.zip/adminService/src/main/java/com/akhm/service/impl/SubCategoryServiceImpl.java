package com.akhm.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akhm.exception.MyCustomException;
import com.akhm.repository.SubCategoryRepository;
import com.akhm.repository.enity.SubCategoryEntity;
import com.akhm.service.SubCategoryService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SubCategoryServiceImpl  implements SubCategoryService{
	@Autowired
	private SubCategoryRepository subCategoryRepository;

	@Override
	public Integer insertSubCategory(SubCategoryEntity subCategoryEntity) {
		log.info("{}-ServiceImpl insertSubCategory() Started");
		try {
			log.info("{}-ServiceImpl insertSubCategories() saving SubCategory");
			SubCategoryEntity category=subCategoryRepository.save(subCategoryEntity);
			if(category!=null) {
				return category.getCategoryId();
			} else {
				return null;
			}
			
		} catch (Exception e) {
			log.error("{}-ServiceImpl-insertSubCategory()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
	}

	@Override
	public List<SubCategoryEntity> getSubCategories() {
		log.info("{}-ServiceImpl getSubCategories() Started");
		try {
			log.info("{}-ServiceImpl getSubCategories() getting SubCategory");
			return subCategoryRepository.findAll();
		} catch (Exception e) {
			log.error("{}-ServiceImpl-getSubCategories()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public SubCategoryEntity getSubCategory(Integer subCategoryId) {
		log.info("{}-ServiceImpl getSubCategory() Started");
		try {
			log.info("{}-ServiceImpl getSubCategory() getting SubCategory details in repository");
			Optional<SubCategoryEntity> optional=subCategoryRepository.findById(subCategoryId);
			if(optional!=null) {
				return optional.get();
			} else {
				return null;
			}
		} catch (Exception e) {
			log.error("{}-ServiceImpl-updateSubCategory()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
	}

	@Override
	public void updateSubCategory(SubCategoryEntity subCategoryEntity) {
		log.info("{}-ServiceImpl updateSubCategory() Started");
		try {
			log.info("{}-ServiceImpl updateSubCategory() update SubCategory details in repository");
			subCategoryRepository.save(subCategoryEntity);
		} catch (Exception e) {
			log.error("{}-ServiceImpl-updateSubCategory()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}

	@Override
	public void deleteSubCategory(Integer subCategoryId) {
		log.info("{}-ServiceImpl deleteSubCategory() Started");
		try {
			log.info("{}-ServiceImpl deleteSubCategory()");
			subCategoryRepository.deleteById(subCategoryId);
		} catch (Exception e) {
			log.error("{}-ServiceImpl-deleteSubCategory()-exception occured-{}",e.getMessage());
			throw new MyCustomException(e.getMessage());
		}
		
	}
}
