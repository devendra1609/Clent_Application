package com.akhm.repository.enity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity 
@Table
@Setter
@Getter
public class CategoryEntity {
	@Id
	@GeneratedValue
	@Column
	private Integer categoryId;
	private String categoryName;
	private String categoryDescription;
	private String categoryCode;
	
}
