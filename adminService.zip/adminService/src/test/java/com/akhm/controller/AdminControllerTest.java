package com.akhm.controller;

import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.akhm.service.AdminService;

public class AdminControllerTest {
	@InjectMocks
	private AdminController adminController;
	@Mock
	private AdminService adminService;
	public void logInTest() throws Exception{
		
	}
	public void logInElseTest() throws Exception{
		
	}
	public void logIn_ExceptionTest() throws Exception{
		
	}
}
